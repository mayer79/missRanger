# missRanger 1.0.4

* Thanks @markgrujic to suggest an additional argument "returnOOB" to return the average OOB prediction error in the resulting data frame.


