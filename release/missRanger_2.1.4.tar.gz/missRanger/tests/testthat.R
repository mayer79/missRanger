library(testthat)
library(missRanger)

test_check("missRanger")
