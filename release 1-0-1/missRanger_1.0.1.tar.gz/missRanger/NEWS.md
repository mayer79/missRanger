# missRanger 1.0.1

* fixed a bug that causes "missRanger" to stop if each variable contains a missing and the very first imputed variable is a factor.

* better handling of the seed in "missRanger"



