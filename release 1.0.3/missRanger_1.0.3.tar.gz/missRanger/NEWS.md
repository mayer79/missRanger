# missRanger 1.0.3

* Thanks at Andrew Landgraf to make the code working with tibbles. So if the input is a tibble, then the resulting data frame will be a tibble as well.


